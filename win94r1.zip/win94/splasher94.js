'use strict';
!function() {
 le._settings.noSplash = true;
 var StartupSound = new Audio("https://cdn.discordapp.com/attachments/932158175602425877/1059804978350399528/Windows_94_Startup.ogg");
 var newIndex = 1e8;
 var d = document.createElement("DIV");
 le._sound.boot.stop();
 StartupSound.play();
 d.classList.add("fillspace");
 d.style.background = "black";
 d.style.zIndex = newIndex - 10;
 le.devmode = true;
 document.body.appendChild(d);
 le._dom.taskbar.classList.add("hide");
 le._dom.desktop.classList.add("invisible");
 $el.each(".ui_icon", function(a) {
   a.classList.add("hide");
 });
 setTimeout(async function() {
   function a(indata2) {
     return !(100 * Math.random() >= (indata2 || 50));
   }
   function b() {
     return "Starting Windows 94..."
   }
   var moduleBlob = await (await fetch('data:text/html,\n  <html>\n  <head>\n      <style>\n          @font-face {\n              font-family: _tomo;\n              src: url(http://www.windows93.net/c/sys/fonts/tomo/tomo.woff2) format(\'woff2\')\n          }\n          body {\n              font-family: _tomo;\n              font-size: 8px;\n              padding: 0px;\n              margin: 0px;\n          }\n          img {\n              margin-top: -2px\n          }\n      </style>\n  </head>\n  <body>\n  <img src="https://cdn.discordapp.com/attachments/932158175602425877/1059796641504305172/94.jpg">\n  <div style="padding: 4px;margin-top:14px;margin-left: 12px;" id="lds">Loading...</div>\n  </body>\n  </html>')).blob();
   le._dom.taskbar.classList.add("hide");
   le._dom.desktop.classList.add("invisible");
   $el.each(".ui_icon", function(a) {
     a.classList.add("hide");
   });
   var i = $window.call(undefined, {
     center : true,
     title : "Please wait...",
     baseWidth : 417,
     baseHeight : 145,
     animationIn : "none",
     animationOut : "none",
     maximizable : false,
     minimizable : false,
     dockable : false,
     closable : false,
     draggable : false,
     resizable : false,
     dest : d,
     url : URL.createObjectURL(moduleBlob),
     onready : function update() {
       function e() {
         if (g) {
           i.el.body.children[0].contentWindow.document.getElementById("lds").innerText = b();
         }
         if (g) {
           setTimeout(e, 230 * Math.random());
         }
       }
       function update() {
         if (f++, 3 == f && (d.style.background = "#3b6ea5"), 4 == f && (i.el.header.style.background = "linear-gradient(90deg,#0a246a 0,#a6caf0 100%)"), le._wallpaper && 6 == f && (d.style.background = "url(" + le._wallpaper + ")"), 7 == f && (i.close(), g = false, le.devmode = false, le._dom.taskbar.classList.add("hide"), le._dom.desktop.classList.add("invisible"), $el.each(".ui_icon", function(a) {
           a.classList.add("hide");
         })), 8 == f) {
           setTimeout(function() {
             le._dom.taskbar.classList.remove("hide");
             le._dom.desktop.classList.remove("invisible");
           }, 100);
           setTimeout(function() {
             $el.each(".ui_icon", function(a) {
               var Mabs = Math.abs;
               setTimeout(function() {
                 a.classList.remove("hide");
               }, Mabs(1e3 * Math.random()) + 100);
             });
           }, 200);
           try {
           } catch (a) {
           }
           try {
             if (h) {
               document.body.removeChild(d);
             }
           } catch (a) {
           }
           h = false;
           system42.trigger("win94:ready")();
           if (window.$runOnce) {
             setTimeout(function() {
               try {
                 $runOnce;
               } catch (a) {
               }
             }, 300);
           }
         }
         if (h) {
           setTimeout(update, 470 * Math.random());
         }
       }
       newIndex = newIndex * 2;
       d.style.zIndex = newIndex - 10;
       le._dom.taskbar.classList.add("hide");
       le._dom.desktop.classList.add("invisible");
       $el.each(".ui_icon", function(a) {
         a.classList.add("hide");
       });
       var f = 0;
       var g = true;
       var h = true;
       update();
       e();
     }
   });
   newIndex = newIndex * 2;
   d.style.zIndex = newIndex - 10;
   i.el.base.style.padding = "1px 1px 1px 1px";
   i.el.base.style.boxShadow = "rgb(0, 0, 0) 1px 0px 0px 0px, rgb(0, 0, 0) 0px 1px 0px 0px, rgb(0, 0, 0) 1px 1px 0px 0px, rgb(255, 255, 255) 1px 1px 0px 0px inset, rgba(0, 0, 0, 0.5) 0px 0px 1px 1px";
   i.el.header.style.background = "linear-gradient(90deg, #0a246a 0, #a6caf0 100%)";
   i.el.base.classList.add("splash");
   i.el.body.classList.add("splash");
   i.el.footer.classList.add("splash");
   i.el.header.classList.add("splash");
   i.el.title.classList.add("splash");
   le._dom.taskbar.classList.add("hide");
   le._dom.desktop.classList.add("invisible");
   $el.each(".ui_icon", function(a) {
     a.classList.add("hide");
   });
 }, 300);
 le._dom.taskbar.classList.add("hide");
 le._dom.desktop.classList.add("invisible");
 $el.each(".ui_icon", function(a) {
   a.classList.add("hide");
 });
}();